from kkimgaug.lib import BaseCompose
pass